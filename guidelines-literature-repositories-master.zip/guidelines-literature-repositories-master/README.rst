OpenAIRE Guidelines for Literature Repository Managers based on Dublin Core and DataCite Metadata Kernel
========================================================================================================

Release 4.0
~~~~~~~~~~~

.. image:: https://zenodo.org/badge/DOI/10.5281/zenodo.1299203.svg
   :target: https://doi.org/10.5281/zenodo.1299203
   :alt: v.4.0 DOI

.. image:: https://readthedocs.org/projects/openaire-guidelines-for-literature-repository-managers/badge/?version=latest
   :target: https://readthedocs.org/projects/openaire-guidelines-for-literature-repository-managers/?badge=v4.0.0
   :alt: Documentation Status

Status
~~~~~~

.. image:: https://travis-ci.org/openaire/guidelines-literature-repositories.svg?branch=master
   :target: https://travis-ci.org/openaire/guidelines-literature-repositories

.. image:: https://readthedocs.org/projects/openaire-guidelines-for-literature-repository-managers/badge/?version=latest
   :target: https://readthedocs.org/projects/openaire-guidelines-for-literature-repository-managers/?badge=latest
   :alt: Documentation Status

