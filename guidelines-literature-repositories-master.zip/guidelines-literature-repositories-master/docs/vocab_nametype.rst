.. _vocab:nametype:

:orphan:

.. _vocab:nametype_nametype:

name type
=========

.. include:: vocabularies/nametype.rst