.. _vocab:contributortype:

:orphan:

.. _vocab:contributortype_contributortype:

contributor type
================

.. include:: vocabularies/contributortype.rst