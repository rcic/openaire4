.. _vocab:resourcetypegeneral:

:orphan:

.. _vocab:resourcetypegeneral_resourcetypegeneral:

resourcetype general
====================

.. include:: vocabularies/resourcetypegeneral.rst