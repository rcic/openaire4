.. _vocab:funderidentifiertype:

:orphan:

.. _vocab:funderidentifiertype_identifiertype:

funderIdentifier type
========================

.. include:: vocabularies/funderidentifiertype.rst