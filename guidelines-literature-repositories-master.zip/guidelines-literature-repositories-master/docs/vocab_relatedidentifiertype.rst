.. _vocab:relatedidentifiertype:

:orphan:

.. _vocab:relatedidentifiertype_identifiertype:

relatedIdentifier type
======================

.. include:: vocabularies/relatedidentifiertype.rst