.. _vocab:identifiertype:

:orphan:

.. _vocab:identifiertype_identifiertype:

identifier type
===============

.. include:: vocabularies/identifiertype.rst