
*Controlled list values*

* ISNI
* GRID
* Crossref Funder