
*Controlled list values*

* ARK
* DOI
* Handle
* PURL
* URL
* URN
