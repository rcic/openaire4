
*Controlled list values*

* Organizational
* Personal