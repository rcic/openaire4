
*Controlled list values*

* Audiovisual
* Collection
* DataPaper
* Dataset
* Event
* Image
* InteractiveResource
* Model
* PhysicalObject
* Service
* Software
* Sound
* Text
* Workflow
* Other