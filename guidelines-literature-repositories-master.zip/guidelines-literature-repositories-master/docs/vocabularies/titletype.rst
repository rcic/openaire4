
*Controlled List Values:*

* AlternativeTitle
* Subtitle
* TranslatedTitle
* Other