.. _vocab:titletype:

:orphan:

.. _vocab:titletype_titletype:

title type
==========

.. include:: vocabularies/titletype.rst
