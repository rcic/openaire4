.. _vocab:alternateidentifiertype:

:orphan:

.. _vocab:alternateidentifiertype_identifiertype:

alternateIdentifier type
========================

.. include:: vocabularies/relatedidentifiertype.rst