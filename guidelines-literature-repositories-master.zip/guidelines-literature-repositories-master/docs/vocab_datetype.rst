.. _vocab:datetype:

:orphan:

.. _vocab:datetype_datetype:

date type
=========

.. include:: vocabularies/datetype.rst