.. _vocab:relationtype:

:orphan:

.. _vocab:relationtype_relationtype:

relation type
=============

.. include:: vocabularies/relationtype.rst